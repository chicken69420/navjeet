// const number = parseInt(prompt("Enter number of videos", ''));

const container = document.querySelector('.container');

// for(let i = 1; i <= number; i++){
//     let elem = document.createElement('video');
//     elem.src = 'videos/' + i.toString() + '.mp4';
//     elem.controls = 'controls';
//     elem.id = i.toString();
//     elem.className = 'video' + i.toString();
//     elem.
//     elem.style.zIndex = (999 - i).toString();
//     if (i === 1){
//         elem.style.opacity = '1';
//
//     }else{
//         elem.style.opacity = '0';
//     }
//
//     container.appendChild(elem);
// }

// document.querySelector('.video1').play();
const video = document.querySelector('.video1');
video.addEventListener('click', function (){

    video.requestFullscreen();
    setTimeout(()=>{video.play()}, 500);

});

video.addEventListener('ended', function (){
    let id = parseInt(video.id);
    // if (id === number){
    //     return;
    // }
    video.src = 'videos/' + (id + 1).toString() + '.mp4';
    video.id = (id + 1).toString();
    video.style.opacity = '0.8';
    setTimeout(()=>{video.style.opacity = '1'}, 1000);
    setTimeout(()=>{video.play()}, 500);
})

//
// for(let i = 1; i <= number; i++){
//     let src = video.src
//
//
//     video.addEventListener('ended',   function (){
//         video.src = nxt.src;
//         video.play();
//
//         setTimeout(function (){
//                 nxt.requestFullscreen();
//                 nxt.play();
//             },
//             1000);
//     }, false);
//     //
//     // video.addEventListener('play', function (){
//     //     video.requestFullscreen();
//     // })
// }