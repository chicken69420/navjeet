const msgs = [
    ['Rabada to Sam Curran', "short of length delivery on the leg stump, Curran works it to deep square leg"],
    ['What I like the most about you?', " back nice back foot defence is a good sight to watch"],
    ['Rabada to Jadeja, out ', 'At the moment CSK are spending so much time packing that '],
    ['Teri ma ki chut', 'Ma chudale'],
    ['And however much they sprint', 'after that, the train isn\'t waiting for them.']
];
